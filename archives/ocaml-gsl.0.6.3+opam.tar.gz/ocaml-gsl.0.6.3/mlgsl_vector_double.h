
#define BASE_TYPE double

#define CONV_FLAT

#define TYPE(t) t
#define FUNCTION(a,b) a ## _ ## b

#include "mlgsl_vector.h"
