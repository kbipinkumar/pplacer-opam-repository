external mcl: ?inflation:float -> (int * float) array array -> int array array = "caml_mcl"
